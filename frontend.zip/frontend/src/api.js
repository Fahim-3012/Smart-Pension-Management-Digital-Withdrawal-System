import axios from 'axios'

const api = axios.create({ baseURL: (import.meta.env.VITE_API_URL || 'http://localhost:5080') + '/api' })

api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem('token')
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && localStorage.getItem('token')) {
      localStorage.clear()
      window.location.reload()
    }
    return Promise.reject(err)
  }
)

export const errText = (e) => {
  const d = e.response?.data
  return typeof d === 'string' ? d : Array.isArray(d) ? d.join(', ') : 'Something went wrong'
}

export default api
